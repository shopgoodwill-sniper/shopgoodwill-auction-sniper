class ShopGoodwill {
    domain = 'ShopGoodwill.com'
}

module.exports = new ShopGoodwill() 